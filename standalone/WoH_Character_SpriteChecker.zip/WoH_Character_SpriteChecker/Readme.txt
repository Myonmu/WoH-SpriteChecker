To use SpriteChecker:

1. put all your sprites in the folder containing this readme file
2. goto the SpriteChecker folder and launch SpriteChecker.exe, the program will display information on whether pixels are corrected.
3. corrected sprites are stored in a "corrected" folder under the folder containing this readme file.


LIMITATIONS:

1. Can only check character sprites.
2. The transparent color is the lower left pixel of each sprite (same as in-game logic)
3. Your transparent color must have a saturation value higher than 127.
   * any color with brightness lower than 127 will be considered black.
   * any color with brightness higher than 127 and saturation lower than 127 will be considered white.
4. Currently does not support checking 2-bit colors (the purple colors) 

NOTE:

icon sprite is safe, the program will skip transparent color retrieval.  