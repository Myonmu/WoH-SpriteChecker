opencv_version = "4.8.0.74"
contrib = False
headless = False
rolling = False
ci_build = True